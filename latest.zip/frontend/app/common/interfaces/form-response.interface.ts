export interface FormResponse {
    error: string;
  }