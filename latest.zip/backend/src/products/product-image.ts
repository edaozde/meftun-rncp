import { join } from 'path';

export const PRODUCT_IMAGES = join(
  __dirname,
  '../../',
  'public/images/products',
);
